# to keep it small, unit is parsec.solar_mass-1.(km/s)²
G = 4.30091e-3
