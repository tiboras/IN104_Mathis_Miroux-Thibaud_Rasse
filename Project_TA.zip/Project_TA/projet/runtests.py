import unittest
import simulator.tests

if __name__ == '__main__':
    unittest.main(simulator.tests)
